1. Cài file autoit-v3-setup.exe
2. chạy file GetTruyenV1.0.au3
3. Truyen sẽ output tại folder Truyen
